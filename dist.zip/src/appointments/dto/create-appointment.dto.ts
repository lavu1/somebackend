export class CreateAppointmentDto {}
