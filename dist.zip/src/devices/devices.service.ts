import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { DeleteResult, Repository, UpdateResult } from 'typeorm';
import { CreateDeviceDto } from './dto/create-device.dto';
import { UpdateDeviceDto } from './dto/update-device.dto';
import { Device } from './entities/device.entity';

@Injectable()
export class DevicesService {
  constructor(
    @InjectRepository(Device)
    private deviceRepository: Repository<Device>,
  ) {}

  create(createDeviceDto: CreateDeviceDto) {
    const device = this.deviceRepository.create(createDeviceDto);
    return device;
  }

  findAll(): Promise<any[]> {
    const devices = this.deviceRepository.find();
    return devices;
  }

  findOne(deviceId: number): Promise<any> {
    const device = this.deviceRepository.findOne(deviceId);
    return device;
  }

  update(
    deviceId: number,
    updateDeviceDto: UpdateDeviceDto,
  ): Promise<UpdateResult> {
    const device = this.deviceRepository.update(deviceId, updateDeviceDto);
    return device;
  }

  remove(deviceId: number): Promise<DeleteResult> {
    const device = this.deviceRepository.delete(deviceId);
    return device;
  }
}
