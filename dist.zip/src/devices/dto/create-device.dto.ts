export class CreateDeviceDto {}
