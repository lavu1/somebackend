import { Entity, PrimaryGeneratedColumn, Column, Generated } from 'typeorm';

@Entity()
export class Device {
  @PrimaryGeneratedColumn('increment')
  public deviceId: number;

  @Column()
  @Generated('uuid')
  uuid: string;

  @Column({ nullable: true })
  serialNumber: string;

  @Column({ nullable: true })
  deviceType: string;
}
