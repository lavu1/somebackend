export class CreateFleetOwnerDto {}
