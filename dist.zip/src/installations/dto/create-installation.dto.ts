export class CreateInstallationDto {}
