export class CreateJobSiteDto {}
