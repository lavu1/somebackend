export class CreateOfficePersonelDto {}
