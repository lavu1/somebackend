export class CreateTelematicsProviderDto {}
