export class CreateTypeOfServiceDto {}
