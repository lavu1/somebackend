export class CreateVehicleDto {}
