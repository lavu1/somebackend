export class CreateWorkOrderDto {}
